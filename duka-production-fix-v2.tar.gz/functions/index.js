const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();

const auth = getAuth();
const db = getFirestore();

const ROLES = new Set([
  "Administrator",
  "Manager",
  "Cashier",
  "Storekeeper",
]);

function cleanString(value, field, maxLength = 200) {
  if (typeof value !== "string") {
    throw new HttpsError("invalid-argument", `${field} must be a string.`);
  }
  const valueTrimmed = value.trim();
  if (!valueTrimmed || valueTrimmed.length > maxLength) {
    throw new HttpsError("invalid-argument", `${field} is invalid.`);
  }
  return valueTrimmed;
}

exports.createEmployee = onCall(
  {
    region: "us-central1",
    timeoutSeconds: 30,
    memory: "256MiB",
    // Keep false until App Check is configured for this web app.
    enforceAppCheck: false,
  },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Login required.");
    }

    const callerUid = request.auth.uid;
    const callerRef = db.collection("Users").doc(callerUid);
    const callerSnap = await callerRef.get();

    if (!callerSnap.exists) {
      throw new HttpsError("permission-denied", "User profile not found.");
    }

    const caller = callerSnap.data() || {};

    if (caller.status !== "active" || caller.role !== "Administrator") {
      throw new HttpsError(
        "permission-denied",
        "Administrator privileges are required."
      );
    }

    const name = cleanString(request.data?.name, "name", 120);
    const email = cleanString(request.data?.email, "email", 254).toLowerCase();
    const password = cleanString(request.data?.password, "password", 128);
    const role = cleanString(request.data?.role, "role", 30);

    if (!/^\\S+@\\S+\\.\\S+$/.test(email)) {
      throw new HttpsError("invalid-argument", "Invalid email address.");
    }
    if (password.length < 6) {
      throw new HttpsError("invalid-argument", "Password must be at least 6 characters.");
    }
    if (!ROLES.has(role)) {
      throw new HttpsError("invalid-argument", "Invalid employee role.");
    }

    let newUser = null;

    try {
      newUser = await auth.createUser({
        email,
        password,
        displayName: name,
        disabled: false,
      });

      await db.collection("Users").doc(newUser.uid).set({
        name,
        email,
        emailLower: email,
        role,
        status: "active",
        createdByUid: callerUid,
        createdByName: caller.name || "",
        createdAt: FieldValue.serverTimestamp(),
      });

      await db.collection("auditLog").add({
        action: "User created",
        details: `${name} (${email}) — ${role}`,
        actorUid: callerUid,
        actorName: caller.name || "",
        targetUid: newUser.uid,
        createdAt: FieldValue.serverTimestamp(),
      });

      return { ok: true, uid: newUser.uid };
    } catch (error) {
      if (newUser?.uid) {
        try {
          await auth.deleteUser(newUser.uid);
        } catch (cleanupError) {
          console.error("Auth cleanup failed:", cleanupError);
        }
      }

      if (error?.code === "auth/email-already-exists") {
        throw new HttpsError("already-exists", "Email already exists.");
      }

      if (error instanceof HttpsError) {
        throw error;
      }

      console.error("createEmployee failed:", error);
      throw new HttpsError("internal", "Failed to create employee.");
    }
  }
);
